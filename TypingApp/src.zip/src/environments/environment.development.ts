export const environment = {
    prodction: false,
    //apiUrl:'https://localhost:8081/api/'
    apiUrl:'https://localhost:7018/api/'
};

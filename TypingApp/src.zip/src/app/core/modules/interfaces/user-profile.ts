export interface UserProfile {
  fullName: string;
  level: number;
  experiencePoints: number;
  experienceToNextLevel: number;
  achievements: string[];
}
